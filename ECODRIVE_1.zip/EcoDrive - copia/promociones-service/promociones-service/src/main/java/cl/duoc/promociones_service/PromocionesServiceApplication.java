package cl.duoc.promociones_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PromocionesServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PromocionesServiceApplication.class, args);
	}

}
